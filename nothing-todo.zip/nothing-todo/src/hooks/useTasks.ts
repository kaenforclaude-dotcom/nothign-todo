import { useEffect, useState, useCallback } from "react";
import { tasks as taskService } from "../services";
import type { Task, CreateTaskInput, UpdateTaskInput } from "../types/task";

// Everything a component needs to work with tasks lives here.
// Components never call the service directly or manage this state themselves —
// they just call the functions this hook returns.
export function useTasks() {
  const [items, setItems] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    taskService
      .getTasks()
      .then((data) => {
        if (!cancelled) setItems(data);
      })
      .catch(() => {
        if (!cancelled) setError("Couldn't load your tasks.");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const addTask = useCallback(async (input: CreateTaskInput) => {
    const created = await taskService.createTask(input);
    setItems((prev) => [created, ...prev]);
  }, []);

  const editTask = useCallback(async (id: string, input: UpdateTaskInput) => {
    const updated = await taskService.updateTask(id, input);
    setItems((prev) => prev.map((t) => (t.id === id ? updated : t)));
  }, []);

  const toggleTask = useCallback(
    async (id: string) => {
      const current = items.find((t) => t.id === id);
      if (!current) return;
      await editTask(id, { completed: !current.completed });
    },
    [items, editTask]
  );

  const removeTask = useCallback(async (id: string) => {
    setItems((prev) => prev.filter((t) => t.id !== id)); // optimistic
    try {
      await taskService.deleteTask(id);
    } catch {
      setError("Couldn't delete that task.");
    }
  }, []);

  return { items, isLoading, error, addTask, editTask, toggleTask, removeTask };
}
