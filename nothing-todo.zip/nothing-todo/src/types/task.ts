// Core shape of a task. Keeping this in its own file means the UI,
// the service layer, and a future backend can all agree on the same contract.

export type TaskCategory = "personal" | "work" | "urgent";

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  category: TaskCategory;
  createdAt: string; // ISO date string
  completedAt: string | null;
}

// What the UI sends when creating a task.
// The service layer fills in id / createdAt / completed.
export interface CreateTaskInput {
  title: string;
  category: TaskCategory;
}

// What the UI sends when editing a task. Every field optional (partial update).
export interface UpdateTaskInput {
  title?: string;
  category?: TaskCategory;
  completed?: boolean;
}
