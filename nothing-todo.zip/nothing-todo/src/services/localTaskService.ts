import type { Task } from "../types/task";
import type { TaskService } from "./taskService";

const STORAGE_KEY = "nothing-todo.tasks";

// Small fake delay so loading states feel real and don't just flash.
// Also makes it painless to notice if you forget to `await` something.
const FAKE_LATENCY_MS = 150;
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function readAll(): Task[] {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return seedTasks();
  try {
    return JSON.parse(raw) as Task[];
  } catch {
    return [];
  }
}

function writeAll(tasks: Task[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function seedTasks(): Task[] {
  const now = new Date().toISOString();
  const seed: Task[] = [
    {
      id: crypto.randomUUID(),
      title: "Take a look around",
      completed: false,
      category: "personal",
      createdAt: now,
      completedAt: null,
    },
    {
      id: crypto.randomUUID(),
      title: "Add your first real task",
      completed: false,
      category: "work",
      createdAt: now,
      completedAt: null,
    },
  ];
  writeAll(seed);
  return seed;
}

export const localTaskService: TaskService = {
  async getTasks() {
    await wait(FAKE_LATENCY_MS);
    return readAll();
  },

  async createTask(input) {
    await wait(FAKE_LATENCY_MS);
    const task: Task = {
      id: crypto.randomUUID(),
      title: input.title,
      category: input.category,
      completed: false,
      createdAt: new Date().toISOString(),
      completedAt: null,
    };
    const tasks = [task, ...readAll()];
    writeAll(tasks);
    return task;
  },

  async updateTask(id, input) {
    await wait(FAKE_LATENCY_MS);
    const tasks = readAll();
    const index = tasks.findIndex((t) => t.id === id);
    if (index === -1) throw new Error(`Task ${id} not found`);

    const updated: Task = {
      ...tasks[index],
      ...input,
      completedAt:
        input.completed === undefined
          ? tasks[index].completedAt
          : input.completed
          ? new Date().toISOString()
          : null,
    };
    tasks[index] = updated;
    writeAll(tasks);
    return updated;
  },

  async deleteTask(id) {
    await wait(FAKE_LATENCY_MS);
    writeAll(readAll().filter((t) => t.id !== id));
  },
};
