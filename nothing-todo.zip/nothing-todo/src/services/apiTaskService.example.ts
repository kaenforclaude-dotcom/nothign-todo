// EXAMPLE — not wired up. Rename to apiTaskService.ts and fill in your
// API's base URL when you have a real backend, then flip the export
// in services/index.ts to use this instead of localTaskService.
//
// Because this implements the same TaskService interface, nothing
// in your components, hooks, or pages has to change.

import type { Task, CreateTaskInput, UpdateTaskInput } from "../types/task";
import type { TaskService } from "./taskService";

const BASE_URL = "https://your-api.example.com/api";

export const apiTaskService: TaskService = {
  async getTasks() {
    const res = await fetch(`${BASE_URL}/tasks`);
    if (!res.ok) throw new Error("Failed to load tasks");
    return res.json();
  },

  async createTask(input: CreateTaskInput) {
    const res = await fetch(`${BASE_URL}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    if (!res.ok) throw new Error("Failed to create task");
    return res.json();
  },

  async updateTask(id: string, input: UpdateTaskInput) {
    const res = await fetch(`${BASE_URL}/tasks/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
    if (!res.ok) throw new Error("Failed to update task");
    return res.json();
  },

  async deleteTask(id: string) {
    const res = await fetch(`${BASE_URL}/tasks/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete task");
  },
};

// Unused imports below silence "declared but never read" if you paste
// this in before wiring it up fully.
export type { Task };
