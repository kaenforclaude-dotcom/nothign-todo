import { localTaskService } from "./localTaskService";
// import { apiTaskService } from "./apiTaskService"; // ← your future backend

// This is the ONLY line you change to connect a real backend.
// Every component imports `tasks` from here, never the implementation directly.
export const tasks = localTaskService;
// export const tasks = apiTaskService;
