import type { Task, CreateTaskInput, UpdateTaskInput } from "../types/task";

// This is the contract the rest of the app talks to.
// Today it's implemented with localStorage (see localTaskService.ts).
// Later, write an apiTaskService.ts that implements the same methods
// with fetch() calls to your backend, then swap it in taskService.ts's
// export at the bottom of this file — nothing in your components changes.
export interface TaskService {
  getTasks(): Promise<Task[]>;
  createTask(input: CreateTaskInput): Promise<Task>;
  updateTask(id: string, input: UpdateTaskInput): Promise<Task>;
  deleteTask(id: string): Promise<void>;
}
