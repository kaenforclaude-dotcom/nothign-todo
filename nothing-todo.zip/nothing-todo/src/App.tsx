import { useMemo } from "react";
import { Header } from "./components/Header";
import { TaskInput } from "./components/TaskInput";
import { TaskSection } from "./components/TaskSection";
import { EmptyState } from "./components/EmptyState";
import { useTasks } from "./hooks/useTasks";
import { useTheme } from "./hooks/useTheme";
import type { TaskCategory } from "./types/task";

export default function App() {
  const { items, isLoading, error, addTask, editTask, toggleTask, removeTask } = useTasks();
  const { isDark, toggleTheme } = useTheme();

  const { active, completed } = useMemo(() => {
    return {
      active: items.filter((t) => !t.completed),
      completed: items.filter((t) => t.completed),
    };
  }, [items]);

  function handleAdd(title: string, category: TaskCategory) {
    addTask({ title, category });
  }

  function handleEdit(id: string, title: string) {
    editTask(id, { title });
  }

  return (
    <div className="min-h-screen">
      <main className="mx-auto max-w-[560px] px-6 py-12 sm:py-16">
        <Header isDark={isDark} onToggleTheme={toggleTheme} />

        <TaskInput onAdd={handleAdd} />

        {error && (
          <p className="mb-6 border border-accent/30 bg-accent/5 px-3 py-2 text-sm text-accent">
            {error}
          </p>
        )}

        {isLoading ? (
          <p className="py-16 text-center font-mono text-xs uppercase tracking-wide text-[var(--text-faint)]">
            Loading…
          </p>
        ) : items.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <TaskSection
              title="Today"
              tasks={active}
              emptyMessage="All clear. Nothing left to do."
              onToggle={toggleTask}
              onDelete={removeTask}
              onEdit={handleEdit}
            />
            <TaskSection
              title="Completed"
              tasks={completed}
              emptyMessage="Nothing completed yet."
              onToggle={toggleTask}
              onDelete={removeTask}
              onEdit={handleEdit}
            />
          </>
        )}
      </main>
    </div>
  );
}
