interface ThemeToggleProps {
  isDark: boolean;
  onToggle: () => void;
}

export function ThemeToggle({ isDark, onToggle }: ThemeToggleProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={isDark}
      aria-label="Toggle dark mode"
      onClick={onToggle}
      className="relative h-6 w-11 shrink-0 rounded-full border border-[var(--border-strong)] bg-transparent transition-colors duration-200"
    >
      <span
        className={`absolute top-0.5 h-4 w-4 rounded-full bg-[var(--text)] transition-transform duration-200 ease-out ${
          isDark ? "translate-x-[22px]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}
