import { ThemeToggle } from "./ThemeToggle";

interface HeaderProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

const today = new Date().toLocaleDateString(undefined, {
  weekday: "short",
  month: "short",
  day: "numeric",
});

export function Header({ isDark, onToggleTheme }: HeaderProps) {
  return (
    <header className="flex items-center justify-between pb-8">
      <div className="flex items-center gap-2.5">
        <span
          aria-hidden
          className="h-2.5 w-2.5 rounded-full bg-accent"
        />
        <span className="text-lg font-medium tracking-tight">Tasks</span>
      </div>

      <div className="flex items-center gap-4">
        <span className="hidden font-mono text-xs text-[var(--text-faint)] sm:inline">
          {today}
        </span>
        <ThemeToggle isDark={isDark} onToggle={onToggleTheme} />
      </div>
    </header>
  );
}
