import { useRef, useState, useEffect, type KeyboardEvent } from "react";
import type { Task } from "../types/task";

interface TaskItemProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, title: string) => void;
}

const CATEGORY_LABEL: Record<Task["category"], string> = {
  personal: "Personal",
  work: "Work",
  urgent: "Urgent",
};

export function TaskItem({ task, onToggle, onDelete, onEdit }: TaskItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [draft, setDraft] = useState(task.title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing) inputRef.current?.focus();
  }, [isEditing]);

  function commitEdit() {
    const trimmed = draft.trim();
    if (trimmed && trimmed !== task.title) {
      onEdit(task.id, trimmed);
    } else {
      setDraft(task.title);
    }
    setIsEditing(false);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") commitEdit();
    if (e.key === "Escape") {
      setDraft(task.title);
      setIsEditing(false);
    }
  }

  return (
    <li className="group flex items-center gap-3 border-b border-[var(--border)] py-3.5 last:border-b-0">
      <button
        type="button"
        role="checkbox"
        aria-checked={task.completed}
        aria-label={task.completed ? "Mark as not done" : "Mark as done"}
        onClick={() => onToggle(task.id)}
        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border transition-all duration-150 ${
          task.completed
            ? "border-accent bg-accent"
            : "border-[var(--border-strong)] hover:border-accent"
        }`}
      >
        {task.completed && (
          <svg width="10" height="8" viewBox="0 0 10 8" fill="none" aria-hidden>
            <path
              d="M1 4L3.5 6.5L9 1"
              stroke="white"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>

      {isEditing ? (
        <input
          ref={inputRef}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commitEdit}
          onKeyDown={handleKeyDown}
          className="min-w-0 flex-1 bg-transparent text-[15px] focus:outline-none"
        />
      ) : (
        <button
          type="button"
          onDoubleClick={() => setIsEditing(true)}
          className={`min-w-0 flex-1 truncate text-left text-[15px] transition-colors duration-150 ${
            task.completed ? "text-[var(--text-muted)] line-through" : "text-[var(--text)]"
          }`}
        >
          {task.title}
        </button>
      )}

      <span
        className={`hidden shrink-0 font-mono text-[10px] uppercase tracking-wide sm:inline ${
          task.category === "urgent" ? "text-accent" : "text-[var(--text-faint)]"
        }`}
      >
        {CATEGORY_LABEL[task.category]}
      </span>

      <div className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity duration-150 group-hover:opacity-100 group-focus-within:opacity-100">
        <button
          type="button"
          aria-label="Edit task"
          onClick={() => setIsEditing(true)}
          className="flex h-7 w-7 items-center justify-center rounded-full text-[var(--text-faint)] transition-colors duration-150 hover:bg-[var(--border)] hover:text-[var(--text)]"
        >
          <EditIcon />
        </button>
        <button
          type="button"
          aria-label="Delete task"
          onClick={() => onDelete(task.id)}
          className="flex h-7 w-7 items-center justify-center rounded-full text-[var(--text-faint)] transition-colors duration-150 hover:bg-accent/10 hover:text-accent"
        >
          <TrashIcon />
        </button>
      </div>
    </li>
  );
}

function EditIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M9.5 1.5L12.5 4.5L4.5 12.5H1.5V9.5L9.5 1.5Z"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M2 3.5H12M5.5 3.5V2H8.5V3.5M3.5 3.5V12H10.5V3.5"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
