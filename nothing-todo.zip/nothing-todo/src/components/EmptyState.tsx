export function EmptyState() {
  return (
    <div className="flex flex-col items-center gap-4 border-b border-[var(--border)] py-16 text-center">
      <div className="dot-grid h-14 w-14 rounded-full" />
      <div>
        <p className="text-[15px]">Nothing here yet</p>
        <p className="mt-1 text-sm text-[var(--text-faint)]">
          Add your first task above.
        </p>
      </div>
    </div>
  );
}
