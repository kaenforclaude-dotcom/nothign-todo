import { useState, type FormEvent } from "react";
import type { TaskCategory } from "../types/task";

interface TaskInputProps {
  onAdd: (title: string, category: TaskCategory) => void;
}

const CATEGORIES: { value: TaskCategory; label: string }[] = [
  { value: "personal", label: "Personal" },
  { value: "work", label: "Work" },
  { value: "urgent", label: "Urgent" },
];

export function TaskInput({ onAdd }: TaskInputProps) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<TaskCategory>("personal");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = title.trim();
    if (!trimmed) return;
    onAdd(trimmed, category);
    setTitle("");
  }

  return (
    <form onSubmit={handleSubmit} className="mb-10">
      <div className="flex items-center gap-3 border-b border-[var(--border-strong)] pb-3 transition-colors focus-within:border-accent">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Add a task…"
          className="min-w-0 flex-1 bg-transparent text-[15px] placeholder:text-[var(--text-faint)] focus:outline-none"
        />
        <button
          type="submit"
          disabled={!title.trim()}
          aria-label="Add task"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-accent text-white transition-transform duration-150 hover:scale-105 active:scale-95 disabled:opacity-30 disabled:hover:scale-100"
        >
          <PlusIcon />
        </button>
      </div>

      <div className="mt-3 flex gap-2">
        {CATEGORIES.map(({ value, label }) => (
          <button
            key={value}
            type="button"
            onClick={() => setCategory(value)}
            aria-pressed={category === value}
            className={`rounded-full border px-3 py-1 font-mono text-[11px] uppercase tracking-wide transition-colors duration-150 ${
              category === value
                ? "border-accent text-accent"
                : "border-[var(--border)] text-[var(--text-faint)] hover:text-[var(--text-muted)]"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </form>
  );
}

function PlusIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
      <path
        d="M7 1V13M1 7H13"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}
