import type { Task } from "../types/task";
import { TaskItem } from "./TaskItem";

interface TaskSectionProps {
  title: string;
  tasks: Task[];
  emptyMessage: string;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string, title: string) => void;
}

export function TaskSection({
  title,
  tasks,
  emptyMessage,
  onToggle,
  onDelete,
  onEdit,
}: TaskSectionProps) {
  return (
    <section className="mb-8">
      <div className="mb-1 flex items-baseline justify-between">
        <h2 className="font-mono text-xs uppercase tracking-wide text-[var(--text-faint)]">
          {title}
        </h2>
        <span className="font-mono text-xs text-[var(--text-faint)]">
          {String(tasks.length).padStart(2, "0")}
        </span>
      </div>

      {tasks.length === 0 ? (
        <p className="border-b border-[var(--border)] py-5 text-sm text-[var(--text-faint)]">
          {emptyMessage}
        </p>
      ) : (
        <ul>
          {tasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onToggle={onToggle}
              onDelete={onDelete}
              onEdit={onEdit}
            />
          ))}
        </ul>
      )}
    </section>
  );
}
