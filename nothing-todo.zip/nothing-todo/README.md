# Tasks — a minimal to-do app

A premium, minimal to-do list app with a Nothing OS–inspired look:
black/white/off-white, one red accent, thin hairline borders, a subtle
dot grid, and a monospace face for small labels.

## Run it locally

```bash
npm install
npm run dev
```

Then open the URL it prints (usually http://localhost:5173).

## Project structure

```
src/
  types/task.ts             Shared Task type — the single source of truth
                             for what a task looks like.

  services/
    taskService.ts           The interface (contract) any backend must match.
    localTaskService.ts       Current implementation — stores tasks in
                             localStorage. This is what the app uses today.
    apiTaskService.example.ts Example of what a real backend version looks
                             like, using fetch(). Not wired up yet.
    index.ts                  The single switch: change one line here to
                             swap from local storage to a real API.

  hooks/
    useTasks.ts                All task state + actions (add/edit/toggle/
                             delete) live here. Components just call these
                             functions — they never touch the service or
                             localStorage directly.
    useTheme.ts                Dark/light mode, persisted to localStorage.

  components/
    Header.tsx, ThemeToggle.tsx, TaskInput.tsx, TaskItem.tsx,
    TaskSection.tsx, EmptyState.tsx
                             Small, single-purpose UI pieces. Each one only
                             receives data and callback props — no data
                             fetching happens inside a component.

  App.tsx                    Wires the hook to the components. This is the
                             only file that needs to change if you add a
                             new section (e.g. "This Week").
```

## Connecting a real backend later

1. Build your backend with whatever you like (Node, Python, etc.) exposing
   endpoints that match the shape in `src/services/taskService.ts`.
2. Copy `src/services/apiTaskService.example.ts` to
   `src/services/apiTaskService.ts`, rename `apiTaskService`, and point
   `BASE_URL` at your API.
3. Open `src/services/index.ts` and switch the export to
   `apiTaskService` instead of `localTaskService`.

That's it — no component or hook needs to change, because they only ever
talk to the `TaskService` interface, never to `localStorage` or `fetch`
directly.

## Notes

- Tasks persist in your browser's `localStorage` until you connect a
  real backend.
- Dark mode is the default on first visit if your system prefers dark;
  otherwise it respects whatever you last chose.
- Double-click (or use the pencil icon on hover) to rename a task.
